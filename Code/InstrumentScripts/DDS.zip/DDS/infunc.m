function infunct(obj,param)
    disp(param)
end
